// Main app logic for Women Safety Toolkit
document.addEventListener('DOMContentLoaded', () => {

    // Basic auth redirect
    if (!localStorage.getItem('wst_user')) {
        location.href = 'login.html';
        return;
    }

    const user = JSON.parse(localStorage.getItem('wst_user'));

    // UI elements
    const sosBtn = document.getElementById('sosBtn');
    const alarmToggle = document.getElementById('alarmToggle');
    const flashScreen = document.getElementById('flashScreen');
    const fakeCall = document.getElementById('fakeCall');
    const startFakeCall = document.getElementById('startFakeCall');
    const answerCall = document.getElementById('answerCall');
    const declineCall = document.getElementById('declineCall');
    const strobeBtn = document.getElementById('strobeBtn');
    const shareWhats = document.getElementById('shareWhats');
    const shareSms = document.getElementById('shareSms');
    const prefillSms = document.getElementById('prefillSms');
    const prefillCall = document.getElementById('prefillCall');
    const panicBtn = document.getElementById('panicBtn');
    const voiceRecorderBtn = document.getElementById('voiceRecorderBtn');
    const recordingIndicator = document.getElementById('recordingIndicator');
    const stopRecordingBtn = document.getElementById('stopRecordingBtn');
    const cameraModal = document.getElementById('cameraModal');
    const vid = document.getElementById('vid');
    const snapBtn = document.getElementById('snapBtn');
    const photoCanvas = document.getElementById('photoCanvas');
    const closeCam = document.getElementById('closeCam');
    const logoutBtn = document.getElementById('logoutBtn');

    // Theme toggle
    document.getElementById('themeToggle').addEventListener('click', () => {
        document.documentElement.classList.toggle('high-contrast');
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('wst_user');
        location.href = 'login.html';
    });

    // Alarm: play sound, vibrate, and flash
    let alarmAudio = new Audio();
    alarmAudio.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=';

    let alarmActive = false;

    function startAlarm() {
        alarmActive = true;
        alarmAudio.loop = true;
        alarmAudio.play().catch(() => {});
        navigator.vibrate && navigator.vibrate([500, 200, 500]);
        flashScreen.classList.remove('hidden');
        flashScreen.style.background = 'white';
        flashScreen.style.opacity = '1';
    }

    function stopAlarm() {
        alarmActive = false;
        alarmAudio.pause();
        navigator.vibrate && navigator.vibrate(0);
        flashScreen.classList.add('hidden');
    }
    alarmToggle.addEventListener('click', () => alarmActive ? stopAlarm() : startAlarm());
    sosBtn.addEventListener('click', startAlarm);

    // Predefined callers with photos and numbers
    const callers = [
        { name: 'Mom', photo: '👩', number: '+91 98765 43210' },
        { name: 'Dad', photo: '👨', number: '+91 98765 43211' },
        { name: 'Brother', photo: '👦', number: '+91 98765 43212' },
        { name: 'Uncle', photo: '👴', number: '+91 98765 43213' },
        { name: 'Aunt', photo: '👵', number: '+91 98765 43214' },
        { name: 'Police', photo: '👮', number: '+91 100' },
        { name: 'Priya', photo: '👩', number: '+91 98765 43215' },
        { name: 'Rajesh', photo: '👨', number: '+91 98765 43216' },
        { name: 'Emergency', photo: '🚨', number: '1091' }
    ];

    // Fake call: show overlay with ringtone, vibration, and random caller
    startFakeCall.addEventListener('click', () => {
        const randomCaller = callers[Math.floor(Math.random() * callers.length)];
        document.getElementById('callerName').textContent = randomCaller.name;
        document.getElementById('callerPhoto').textContent = randomCaller.photo;
        document.getElementById('callerNumber').textContent = randomCaller.number;
        fakeCall.classList.remove('hidden');
        const ringtone = new Audio();
        ringtone.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=';
        ringtone.loop = true;
        ringtone.play().catch(() => {});
        fakeCall._ring = ringtone;
        // Add vibration
        if (navigator.vibrate) {
            navigator.vibrate([200, 100, 200, 100, 200]); // Pattern: vibrate, pause, vibrate, etc.
        }
    });

    let callTimer;
    let callStartTime;

    answerCall.addEventListener('click', (e) => {
        e.stopPropagation();
        const r = fakeCall._ring;
        if (r) { r.pause(); }
        if (navigator.vibrate) navigator.vibrate(0); // Stop vibration
        // Switch to connected screen
        document.getElementById('call-screen').classList.add('hidden');
        document.getElementById('connectedScreen').classList.remove('hidden');
        // Set connected info
        document.getElementById('connectedName').textContent = document.getElementById('callerName').textContent;
        document.getElementById('connectedNumber').textContent = document.getElementById('callerNumber').textContent;
        // Start call timer
        callStartTime = Date.now();
        callTimer = setInterval(updateCallDuration, 1000);
    });

    function updateCallDuration() {
        const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        document.getElementById('callDuration').textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    document.getElementById('hangUpBtn').addEventListener('click', () => {
        clearInterval(callTimer);
        document.getElementById('connectedScreen').classList.add('hidden');
        fakeCall.classList.add('hidden');
    });
    declineCall.addEventListener('click', (e) => {
        e.stopPropagation();
        const r = fakeCall._ring;
        if (r) { r.pause(); }
        if (navigator.vibrate) navigator.vibrate(0); // Stop vibration
        fakeCall.classList.add('hidden');
    });

    // Strobe / flashlight simulated by toggling flashScreen
    let strobeInt = null;
    strobeBtn.addEventListener('click', () => {
        if (strobeInt) {
            clearInterval(strobeInt);
            strobeInt = null;
            flashScreen.classList.add('hidden');
        } else {
            flashScreen.classList.remove('hidden');
            strobeInt = setInterval(() => {
                flashScreen.style.background = flashScreen.style.background === 'white' ? 'black' : 'white';
            }, 120);
        }
    });

    // Share location functions
    async function getLocationLink() {
        if (!navigator.geolocation) return null;
        return new Promise((res, rej) => {
            navigator.geolocation.getCurrentPosition((pos) => {
                const lat = pos.coords.latitude,
                    lon = pos.coords.longitude;
                res(`https://maps.google.com/?q=${lat},${lon}`);
            }, err => res('Location unavailable'));
        });
    }

    shareWhats.addEventListener('click', async() => {
        const link = await getLocationLink();
        const text = encodeURIComponent('I need help — my live location: ' + link);
        window.open(`https://wa.me/?text=${text}`, '_blank');
    });

    shareSms.addEventListener('click', async() => {
        const link = await getLocationLink();
        const body = encodeURIComponent('I need help — my live location: ' + link);
        window.location.href = `sms:?&body=${body}`;
    });

    prefillSms.addEventListener('click', () => {
        const body = encodeURIComponent('I am not safe. Please call me.');
        window.location.href = `sms:?&body=${body}`;
    });

    prefillCall.addEventListener('click', () => {
        window.location.href = 'tel:1091';
    });

    // Panic Mode: capture photo + alarm + location share
    panicBtn.addEventListener('click', async() => {
        startAlarm();
        cameraModal.classList.remove('hidden');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
            vid.srcObject = stream;
            vid._stream = stream;
        } catch (e) {
            console.warn('Camera unavailable', e);
        }
        const link = await getLocationLink();
        const body = encodeURIComponent('PANIC MODE — my last location: ' + link);
        if (confirm('Panic mode triggered. Prefill SMS with current location?')) {
            window.location.href = `sms:?&body=${body}`;
        }
    });

    // Camera capture
    snapBtn.addEventListener('click', () => {
        const canvas = photoCanvas;
        const video = vid;
        canvas.width = video.videoWidth || 320;
        canvas.height = video.videoHeight || 240;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const data = canvas.toDataURL('image/png');
        let evidence = JSON.parse(localStorage.getItem('wst_evidence') || '[]');
        evidence.push({ time: Date.now(), data });
        localStorage.setItem('wst_evidence', JSON.stringify(evidence));
        alert('Photo captured and saved locally.');
    });

    closeCam.addEventListener('click', () => {
        cameraModal.classList.add('hidden');
        const s = vid._stream;
        if (s) {
            s.getTracks().forEach(t => t.stop());
            vid._stream = null;
        }
    });

    // Simple accordion
    document.querySelectorAll('.acc-head').forEach(btn => {
        btn.addEventListener('click', () => btn.nextElementSibling.classList.toggle('hidden'));
    });

    document.getElementById('fakeCall').addEventListener('click', (e) => {
        if (e.target === document.getElementById('fakeCall')) {
            const r = fakeCall._ring;
            if (r) r.pause();
            fakeCall.classList.add('hidden');
        }
    });

    // Voice Evidence Recorder
    let mediaRecorder;
    let recordedChunks = [];

    voiceRecorderBtn.addEventListener('click', async() => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            recordedChunks = [];
            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    recordedChunks.push(event.data);
                }
            };
            mediaRecorder.onstop = async() => {
                const blob = new Blob(recordedChunks, { type: 'audio/webm' });
                // Encrypt the blob
                const encryptedBlob = await encryptBlob(blob);
                // Save to localStorage
                const timestamp = Date.now();
                const base64 = await blobToBase64(encryptedBlob);
                let evidence = JSON.parse(localStorage.getItem('wst_voice_evidence') || '[]');
                evidence.push({ time: timestamp, data: base64 });
                localStorage.setItem('wst_voice_evidence', JSON.stringify(evidence));
                // Prepare WhatsApp draft
                const contact = localStorage.getItem('wst_whatsapp_contact');
                if (contact) {
                    const text = encodeURIComponent('I’m unsafe—please help. Recorded evidence attached.');
                    window.open(`https://wa.me/${contact}?text=${text}`, '_blank');
                } else {
                    alert('Please set a trusted WhatsApp contact in Safety Settings.');
                }
                // Stop the stream
                stream.getTracks().forEach(track => track.stop());
            };
            mediaRecorder.start();
            recordingIndicator.classList.remove('hidden');
        } catch (e) {
            console.warn('Microphone access denied', e);
            alert('Microphone access is required for voice recording.');
        }
    });

    stopRecordingBtn.addEventListener('click', () => {
        if (mediaRecorder && mediaRecorder.state === 'recording') {
            mediaRecorder.stop();
            recordingIndicator.classList.add('hidden');
        }
    });

    // Helper functions
    async function encryptBlob(blob) {
        const key = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 },
            true, ['encrypt']
        );
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encrypted = await crypto.subtle.encrypt({ name: 'AES-GCM', iv },
            key,
            await blob.arrayBuffer()
        );
        // For simplicity, store key and iv with the data (in real app, handle securely)
        return new Blob([iv, encrypted], { type: 'application/octet-stream' });
    }

    function blobToBase64(blob) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result.split(',')[1]);
            reader.readAsDataURL(blob);
        });
    }

});