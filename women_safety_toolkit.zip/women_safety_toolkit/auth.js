// Authentication (localStorage based)
document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('authForm');
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const user = {
      name: form.name.value.trim(),
      email: form.email.value.trim(),
      gender: form.gender.value,
      age: form.age.value,
      created: Date.now()
    };
    localStorage.setItem('wst_user', JSON.stringify(user));
    location.href = 'index.html';
  });
});
