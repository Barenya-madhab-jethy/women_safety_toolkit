# TODO: Enhance Fake Call Simulator

- [ ] Expand callers array in app.js with phone numbers and more realistic names
- [x] Update index.html overlay to include fake phone number display and carrier name
- [ ] Enhance styles.css for iOS/Android-like call screen styling and add slide-in animation
- [ ] Replace placeholder ringtone in app.js with base64 of a real phone ring sound
- [ ] Change vibration to continuous loop during ringing in app.js
- [x] Add connected state logic in app.js: after answering, show "Connected" screen with call duration timer and hang-up button
- [ ] Test ringtone playback and vibration
- [ ] Ensure overlay animations work on mobile
