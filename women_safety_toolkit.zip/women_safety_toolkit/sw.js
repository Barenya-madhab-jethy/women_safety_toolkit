// very small service worker for offline shell caching
const CACHE = 'wst-shell-v1';
const FILES = [
  '/',
  '/index.html',
  '/login.html',
  '/styles.css',
  '/app.js',
  '/auth.js',
  '/manifest.json'
];
self.addEventListener('install', evt=>{
  evt.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).catch(()=>{}));
  self.skipWaiting();
});
self.addEventListener('activate', evt=> evt.waitUntil(self.clients.claim()));
self.addEventListener('fetch', evt=>{
  evt.respondWith(caches.match(evt.request).then(r=> r || fetch(evt.request).catch(()=>caches.match('/index.html'))));
});
