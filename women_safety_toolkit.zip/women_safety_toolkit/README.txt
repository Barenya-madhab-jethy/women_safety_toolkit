Women Safety Toolkit
--------------------
A simple offline-capable safe toolkit prototype focusing on Indian women's safety.
Features included in this zip:
- Login / Local user storage
- SOS Alarm (sound + vibration + full-screen flash)
- Share Live Location (WhatsApp & SMS prefill)
- Fake Call Simulator
- Flashlight / Strobe (fullscreen)
- Emergency numbers quick-dial
- Quick SMS / Phone prefill
- Panic Mode: capture photo (saved to localStorage) + alarm + location prefill
- Camera evidence capture saved locally
- Basic PWA support (manifest + service worker)
- Accessibility toggles & large font ready

To run:
1. Unzip and open login.html in a modern browser (for camera/geolocation features, use a secure origin like localhost or a web server).
